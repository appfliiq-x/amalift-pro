<div class="sidebar" :class="[{'is-hidden': ! sidebar}]">
    <?php echo $index; ?>

</div><?php /**PATH /var/www/html/tagxii-server/resources/views/vendor/larecipe/partials/sidebar.blade.php ENDPATH**/ ?>